package com.example.dysaver

import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    private val client = OkHttpClient()
    private val ua = "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) " +
        "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1"

    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var btn: Button
    private var lastClip = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        input = EditText(this).apply { hint = "粘贴抖音分享链接（打开App会自动识别剪贴板）" }
        btn = Button(this).apply { text = "下载无水印视频" }
        status = TextView(this).apply { gravity = Gravity.START; setPadding(0, pad, 0, 0) }
        root.addView(input); root.addView(btn); root.addView(status)
        setContentView(root)

        btn.setOnClickListener { start() }
    }

    // 剪贴板只有在界面获得焦点后才能读取
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus) return
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = cm.primaryClip?.getItemAt(0)?.text?.toString() ?: return
        if (text != lastClip && extractUrl(text) != null && "douyin" in text) {
            lastClip = text
            input.setText(text)
            start()
        }
    }

    private fun extractUrl(s: String) =
        Regex("https?://[\\w./?=&%#~:+-]+").find(s)?.value

    private fun start() {
        val url = extractUrl(input.text.toString())
        if (url == null) { status.text = "没有找到链接"; return }
        btn.isEnabled = false
        status.text = "解析中…"
        CoroutineScope(Dispatchers.Main).launch {
            try {
                val msg = withContext(Dispatchers.IO) { process(url) }
                status.text = msg
            } catch (e: Exception) {
                status.text = "失败：${e.message}\n（可能是链接无效，或抖音接口已变化）"
            } finally {
                btn.isEnabled = true
            }
        }
    }

    private fun process(shareUrl: String): String {
        // 1. 跟随短链跳转，拿到视频ID
        val finalUrl = client.newCall(
            Request.Builder().url(shareUrl).header("User-Agent", ua).build()
        ).execute().use { it.request.url.toString() }
        val id = Regex("/video/(\\d+)").find(finalUrl)?.groupValues?.get(1)
            ?: Regex("modal_id=(\\d+)").find(finalUrl)?.groupValues?.get(1)
            ?: error("未识别到视频ID")

        // 2. 请求分享页，解析内嵌 JSON
        val html = client.newCall(
            Request.Builder().url("https://www.iesdouyin.com/share/video/$id/")
                .header("User-Agent", ua).build()
        ).execute().use { it.body?.string() ?: error("页面为空") }

        val marker = html.indexOf("window._ROUTER_DATA")
        if (marker < 0) error("未找到视频数据")
        val s = html.indexOf('{', marker)
        val e = html.indexOf("</script>", s)
        val json = JSONObject(html.substring(s, e).trim().removeSuffix(";"))
        val loader = json.getJSONObject("loaderData")

        var playUrl: String? = null
        var title = id
        for (k in loader.keys()) {
            val info = loader.optJSONObject(k)?.optJSONObject("videoInfoRes") ?: continue
            val item = info.getJSONArray("item_list").getJSONObject(0)
            playUrl = item.getJSONObject("video").getJSONObject("play_addr")
                .getJSONArray("url_list").getString(0)
            title = item.optString("desc", id)
        }
        if (playUrl == null) error("未找到播放地址")

        // 3. 去水印：playwm -> play
        playUrl = playUrl.replace("playwm", "play")

        // 4. 下载并保存到相册（Movies/DouyinSaver）
        val safe = title.replace(Regex("[\\\\/:*?\"<>|\\s#@]+"), "_").take(40).ifEmpty { id }
        val name = "${safe}_$id.mp4"
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/DouyinSaver")
        }
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: error("无法创建文件")

        client.newCall(
            Request.Builder().url(playUrl).header("User-Agent", ua)
                .header("Referer", "https://www.douyin.com/").build()
        ).execute().use { resp ->
            if (!resp.isSuccessful) {
                contentResolver.delete(uri, null, null)
                error("下载失败 HTTP ${resp.code}")
            }
            contentResolver.openOutputStream(uri)!!.use { out ->
                resp.body!!.byteStream().copyTo(out)
            }
        }
        return "已保存到相册：Movies/DouyinSaver/$name"
    }
}
